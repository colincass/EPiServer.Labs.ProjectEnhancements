define(
"dojo/cldr/nls/en-ca/gregorian", //begin v1.x content
{
	"dateFormatItem-MMMMEd": "E, MMMM d",
	"dateFormatItem-MMdd": "MM/dd",
	"dateFormatItem-yyMMM": "MMM yy",
	"dateFormatItem-MMMMd": "MMMM d"
}
//end v1.x content
);